package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavHost;
import androidx.navigation.fragment.NavHostFragment;

import static android.widget.Toast.*;
import static com.example.myapplication.R.id.count_button;
import static com.example.myapplication.R.id.textview_first;
import static com.example.myapplication.R.id.toast_button;

public class FirstFragment extends Fragment {
    private int Counter = 0;
    Button count;
    TextView txv;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        count = (Button) view.findViewById(count_button);
        txv = (TextView) view.findViewById(textview_first);

        count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Counter ++;
                txv.setText(Integer.toString(Counter));
            }
        });

        view.findViewById(R.id.random_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentCount = Integer.parseInt(txv.getText().toString());
                FirstFragmentDirections.ActionFirstFragmentToSecondFragment action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(currentCount);
                NavHostFragment.findNavController(FirstFragment.this).navigate(action);
            }
        });
    }
}

